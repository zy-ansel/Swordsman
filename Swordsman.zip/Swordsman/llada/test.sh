# Set the environment variables first before running the command.
export HF_ALLOW_CODE_EVAL=1
export HF_DATASETS_TRUST_REMOTE_CODE=true

export LLADA_SESSION_DIR="./llada-8B-Instruct_logs/gsm8k"
mkdir -p $LLADA_SESSION_DIR

task=gsm8k
length=512
block_length=32
# length=1024
# block_length=1024
num_fewshot=5
steps=$((length / block_length))
# steps=1024
factor=1.0
model_path='GSAI-ML/LLaDA-8B-Instruct'

accelerate launch eval_llada.py --tasks ${task} --num_fewshot ${num_fewshot} \
--confirm_run_unsafe_code --model llada_dist \
--model_args model_path=${model_path},gen_length=${length},steps=${steps},adaptive='jump',threshold=0.9,show_speed=True,min_block_len=1,max_block_len=32,dynamic_threshold_method="power_decay",base_threshold=0.9,confidence_boost=0.5
