import torch
import numpy as np
import math
import torch.nn.functional as F
import os
from transformers import AutoTokenizer, AutoModel
from model.modeling_llada import LLaDAModelLM
from torch.cuda import nvtx
from sklearn.cluster import KMeans

def add_gumbel_noise(logits, temperature):
    
    if temperature == 0:
        return logits
    logits = logits.to(torch.float64)
    noise = torch.rand_like(logits, dtype=torch.float64)
    gumbel_noise = (- torch.log(noise)) ** temperature
    return logits.exp() / gumbel_noise

def get_num_transfer_tokens(block_mask_index: torch.Tensor, steps: int) -> torch.Tensor:
    
    device = block_mask_index.device
    dtype = torch.long
    total = block_mask_index.sum(dim=1)
    base  = torch.div(total, steps, rounding_mode='floor')
    rem   = total - base * steps
    num_transfer_tokens = base.unsqueeze(1).expand(-1, steps).to(dtype)
    cols = torch.arange(steps, device=device).unsqueeze(0)
    add_mask = cols < rem.unsqueeze(1)
    num_transfer_tokens = num_transfer_tokens + add_mask.to(dtype)
    return num_transfer_tokens

def get_max_entropy_jump_pos(logits, search_start, search_end, window_size=4, metric='entropy', topk_entropy_k=10):
    seq_len = logits.shape[1]
    if search_start >= seq_len:
        return search_start, 0.0
    search_end = min(search_end, seq_len)
    calc_start = max(0, search_start - window_size)
    calc_end_needed = min(search_end + window_size, seq_len)
    slice_logits = logits[:, calc_start:calc_end_needed, :]
    local_metric_tensor = calculate_metric(slice_logits, metric=metric, topk_entropy_k=topk_entropy_k)
    local_metric_vals = local_metric_tensor[0].float().cpu().numpy()
    prefix_sum = np.concatenate(([0.0], np.cumsum(local_metric_vals)))
    max_val = -float('inf')
    best_pos = search_start 
    offset = calc_start 
    for i in range(search_start, search_end):
        rel_i = i - offset
        r_idx_start = rel_i
        r_idx_end = min(rel_i + window_size, len(local_metric_vals))
        if r_idx_end > r_idx_start:
            right_avg = (prefix_sum[r_idx_end] - prefix_sum[r_idx_start]) / (r_idx_end - r_idx_start)
        else:
            right_avg = 0.0
        l_idx_start = max(0, rel_i - window_size)
        l_idx_end = rel_i
        if l_idx_end > l_idx_start:
            left_avg = (prefix_sum[l_idx_end] - prefix_sum[l_idx_start]) / (l_idx_end - l_idx_start)
        else:
            left_avg = 0.0
        diff = right_avg - left_avg
        if diff > max_val:
            max_val = diff
            best_pos = i
    return best_pos, max_val

@torch.no_grad()
def get_max_entropy_jump_pos_clean(logits, search_start, search_end, metric='entropy', topk_entropy_k=10):
    seq_len = logits.shape[1]
    if search_start >= seq_len:
        return search_start, 0.0
    search_end = min(search_end, seq_len)
    if search_start >= search_end:
        return search_start, 0.0
    calc_start = max(0, search_start - 1)
    calc_end = search_end 
    slice_logits = logits[:, calc_start:calc_end, :]
    local_metric_tensor = calculate_metric(slice_logits, metric=metric, topk_entropy_k=topk_entropy_k)
    local_vals = local_metric_tensor[0].float().cpu().numpy() 
    if search_start > 0:
        curr_vals = local_vals[1:]
        prev_vals = local_vals[:-1]
        diffs = curr_vals - prev_vals
    else:
        padded_vals = np.concatenate(([0.0], local_vals))
        diffs = padded_vals[1:] - padded_vals[:-1]
    if len(diffs) == 0:
        return search_start, 0.0
    best_idx = np.argmax(diffs) 
    max_val = diffs[best_idx]
    best_pos = search_start + best_idx
    return int(best_pos), float(max_val)

@torch.no_grad()
def determine_next_block_length(logits, start_idx, min_len=8, max_len=32, metric='entropy',topk_entropy_k=10, minjump = 0.01, visual = False):
    
    seq_len = logits.shape[1]
    search_start = start_idx + min_len
    search_end = min(start_idx + max_len, seq_len)
    if search_start >= seq_len:
        return seq_len - start_idx
    best_jump_pos, jump_val = get_max_entropy_jump_pos_clean(
        logits, 
        search_start=search_start, 
        search_end=search_end, 
        metric=metric,
        topk_entropy_k=topk_entropy_k
    )
    if jump_val < minjump: 
        relative_jump = search_end - start_idx 
    else:
        relative_jump = best_jump_pos - start_idx
    decision = relative_jump
    return min(decision, max_len)

@torch.no_grad()
def calculate_metric(logits, metric='entropy', topk_entropy_k=10):
    logits = logits.float()
    probs = F.softmax(logits, dim=-1)
    if metric == 'entropy':
        log_probs = F.log_softmax(logits, dim=-1) 
        return -torch.sum(probs * log_probs, dim=-1)
    elif metric == 'confidence':
        max_probs, _ = torch.max(probs, dim=-1)
        return 1.0 - max_probs
    elif metric == 'varentropy':
        log_probs = F.log_softmax(logits, dim=-1)
        entropy = -torch.sum(probs * log_probs, dim=-1, keepdim=True)
        diff_sq = (log_probs + entropy) ** 2
        return torch.sum(probs * diff_sq, dim=-1)
    elif metric == 'gap':
        top2_vals, _ = torch.topk(probs, k=2, dim=-1)
        return 1.0 - (top2_vals[..., 0] - top2_vals[..., 1])
    elif metric == 'gini':
        return 1.0 - torch.sum(probs ** 2, dim=-1)
    elif metric == 'topk_entropy':
        topk_probs, _ = torch.topk(probs, k=topk_entropy_k, dim=-1)
        sum_probs = topk_probs.sum(dim=-1, keepdim=True)
        topk_probs = topk_probs / (sum_probs + 1e-10)
        return -torch.sum(topk_probs * torch.log(topk_probs + 1e-10), dim=-1)
    else:
        raise ValueError(f"Unknown metric: {metric}")
@torch.no_grad()
def generate_adaptive(model, prompt, tokenizer=None, steps=128, gen_length=128, 
                      min_block_len=1, max_block_len=32, 
                      adaptive_method='jump',metric='entropy',topk_entropy_k=10,minjump=0.01,
                      kmeans_window=32, kmeans_diff_threshold=0.5, cumulate_threshold=15.0, confidence_boost=1.0,
                      dynamic_threshold_method=None, base_threshold=0.9, min_threshold=0.7,pivot_entropy=1.5,
                      left_first=False, fallback_k=5, min_confidence_diff=0.05,
                      temperature=0., remasking='low_confidence', mask_id=126336,
                      entropy_modify=False,min_entropy_confidence=0.85,visual=False,
                      cart_method = False,cart_lambda=1.0, cart_p=0.5,
                      threshold=None, factor=None, prompt_id="0"):
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    prompt_len = prompt.shape[1]
    total_len = x.shape[1]
    current_idx = prompt_len
    nfe = 0
    block_cnt = 0
    step_ratio = steps / gen_length 
    while current_idx < total_len:
        block_cnt += 1
        x[:, current_idx:] = mask_id 
        logits = model(x).logits 
        nfe += 1
        next_len = determine_next_block_length(
            logits, 
            start_idx=current_idx, 
            min_len=min_block_len, 
            max_len=max_block_len,
            metric=metric,
            topk_entropy_k=topk_entropy_k,
            minjump=minjump,
            visual=visual
        )
        if current_idx + next_len > total_len:
            next_len = total_len - current_idx
        block_end = current_idx + next_len
        current_steps = max(1, int(next_len * step_ratio))
        block_mask_index = (x[:, current_idx:block_end] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, current_steps)
        block_start = current_idx
        i = 0
        initial_block_entropy = 4.0
        while True:
            if i > 0:
                nfe += 1
                logits = model(x).logits
            mask_index = (x == mask_id)
            mask_index[:, block_end:] = 0 
            if dynamic_threshold_method is not None:
                block_logits = logits[:, block_start:block_end, :]
                block_ids = x[:, block_start:block_end] 
                block_metric_vals = calculate_metric(block_logits, metric='entropy') 
                is_still_mask = (block_ids == mask_id)
                masked_metric_vals = block_metric_vals[is_still_mask]
                if masked_metric_vals.numel() > 0:
                    avg_val_mask = masked_metric_vals.float().mean().item()
                else:
                    avg_val_mask = 0.0
                if i==0:
                    initial_block_entropy = avg_val_mask
                threshold = get_dynamic_threshold_by_entropy(
                    current_entropy=avg_val_mask,
                    base_threshold=base_threshold,
                    min_threshold=min_threshold,
                    pivot_entropy=initial_block_entropy,
                    confidence_boost=confidence_boost,
                    method=dynamic_threshold_method
                )
            if factor is None:
                x0, transfer_index = get_transfer_index_origin(
                    logits, temperature, remasking, mask_index, 
                    x, num_transfer_tokens[:, i] if threshold is None else None, threshold)
            else:
                x0, transfer_index = get_transfer_index_dynamic(logits, temperature, remasking, mask_index, x, None, factor)
            x[transfer_index] = x0[transfer_index]
            i += 1
            if (x[:, current_idx:block_end] == mask_id).sum() == 0:
                break
            if i >= current_steps and threshold is None:
                break
        current_idx = block_end
    return x, nfe

@ torch.no_grad()
def generate_origin(model, prompt, steps=128, gen_length=128, block_length=128, temperature=0.,
             remasking='low_confidence', mask_id=126336, threshold=None, factor=None, metric='entropy',
             dynamic_threshold_method=None, base_threshold=0.9, min_threshold=0.7,pivot_entropy=1.5,
             left_first=False, fallback_k=5, min_confidence_diff=0.05):
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    assert gen_length % block_length == 0
    num_blocks = gen_length // block_length
    assert steps % num_blocks == 0
    steps = steps // num_blocks
    nfe = 0 
    for num_block in range(num_blocks):
        block_start = prompt.shape[1] + num_block * block_length
        block_end = prompt.shape[1] + (num_block + 1) * block_length
        block_mask_index = (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 1) * block_length] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, steps)
        i = 0
        initial_block_entropy = pivot_entropy
        while True:
            nfe += 1
            mask_index = (x == mask_id)
            logits = model(x).logits
            mask_index[:, prompt.shape[1] + (num_block + 1) * block_length:] = 0
            if factor is None:
                x0, transfer_index = get_transfer_index_origin(
                    logits, temperature, remasking, mask_index, 
                    x, num_transfer_tokens[:, i] if threshold is None else None, threshold)
            else:
                x0, transfer_index = get_transfer_index_dynamic(logits, temperature, remasking, mask_index, x, None, factor)
            x[transfer_index] = x0[transfer_index]
            i += 1
            if (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 1) * block_length] == mask_id).sum() == 0:
                break
    return x, nfe

@ torch.no_grad()
def get_dynamic_threshold_by_entropy(
    current_entropy, 
    base_threshold=0.9, 
    min_threshold=.0, 
    pivot_entropy=1.5, 
    confidence_boost=1.0, 
    method='linear'
):
    if current_entropy < 0: current_entropy = 0
    raw_ratio = min(current_entropy / pivot_entropy, 1.0)
    if confidence_boost > 1.0:
        ratio = raw_ratio * confidence_boost - (confidence_boost - 1.0)
        ratio = max(0.0, ratio)
    else:
        ratio = raw_ratio
    if method == 'linear':
        factor = ratio
    elif method == 'square':
        factor = ratio ** 2
    elif method == 'cubic':
        factor = ratio ** 3
    elif method == 'sqrt':
        factor = math.sqrt(ratio)
    elif method == 'sigmoid':
        factor = 0.5 * (1 - math.cos(ratio * math.pi))
    elif method == 'step':
        if ratio > 0.8: factor = 1.0
        elif ratio > 0.4: factor = 0.7
        else: factor = 0.0
    elif method == 'power_decay':
        factor = math.pow(raw_ratio, confidence_boost)
    elif method == 'sine':
        factor = math.sin(ratio * (math.pi / 2))
    elif method == 'elliptical':
        factor = math.sqrt(1 - (1 - ratio) ** 2)
    elif method == 'exp':
        k = max(confidence_boost, 0.1) 
        numerator = 1 - math.exp(-k * ratio)
        denominator = 1 - math.exp(-k)
        factor = numerator / denominator
    elif method == 'log':
        k = max(confidence_boost, 0.1)
        factor = math.log(1 + k * ratio) / math.log(1 + k)
    else:
        raise ValueError(f"Unknown method: {method}")
    delta = base_threshold - min_threshold
    dynamic_threshold = min_threshold + delta * factor
    return dynamic_threshold

@ torch.no_grad()
def generate(model, prompt, steps=128, gen_length=128, block_length=128, temperature=0.,
             remasking='low_confidence', mask_id=126336, threshold=None, factor=None,
             dynamic_threshold_method=None, base_threshold=0.9, min_threshold=0.7,pivot_entropy=1.5,
             left_first=False, fallback_k=2,
             num_partitions=1):
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    assert gen_length % block_length == 0
    num_blocks = gen_length // block_length
    assert steps % num_blocks == 0
    steps = steps // num_blocks
    nfe = 0 
    num_blocks = num_blocks-2
    for num_block in range(num_blocks):
        if num_block==num_blocks-1:
            block_mask_index = (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 3) * block_length] == mask_id)
        else:
            block_mask_index = (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 1) * block_length] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, steps)
        i = 0
        while True:
            nfe += 1
            mask_index = (x == mask_id)
            logits = model(x).logits
            if num_block==num_blocks-1:
                mask_index[:, prompt.shape[1] + (num_block + 3) * block_length:] = 0
            else:
                mask_index[:, prompt.shape[1] + (num_block + 1) * block_length:] = 0
            if factor is None:
                x0, transfer_index = get_transfer_index_origin(logits, temperature, remasking, mask_index, x, num_transfer_tokens[:, i] if threshold is None else None, threshold)
            else:
                x0, transfer_index = get_transfer_index_dynamic(logits, temperature, remasking, mask_index, x, None, factor)
            x[transfer_index] = x0[transfer_index]
            i += 1
            if num_block==num_blocks-1:
                if (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 3) * block_length] == mask_id).sum() == 0:
                    break
            else:
                if (x[:, prompt.shape[1] + num_block * block_length: prompt.shape[1] + (num_block + 1) * block_length] == mask_id).sum() == 0:
                    break
    return x, nfe

def get_transfer_index(
    logits: torch.Tensor,
    temperature: float,
    remasking: str,
    mask_index: torch.Tensor, 
    x: torch.Tensor, 
    num_transfer_tokens, 
    threshold: float = None,
    num_partitions: int = 1, 
    active_range: tuple = None
):
    logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
    x0 = torch.argmax(logits_with_noise, dim=-1) 
    if remasking == "low_confidence":
        p = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.gather(p, dim=-1, index=x0.unsqueeze(-1)).squeeze(-1) 
    elif remasking == "random":
        x0_p = torch.rand(x0.shape, device=x0.device, dtype=torch.float64) 
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    neg_inf = torch.tensor(torch.finfo(x0_p.dtype).min, device=x0_p.device, dtype=x0_p.dtype)
    confidence = torch.where(mask_index, x0_p, neg_inf) 
    if threshold is not None:
        transfer_index = mask_index & (confidence >= threshold)
        n_parts = max(1, int(num_partitions))
        force_mask = torch.zeros_like(transfer_index)
        if active_range is not None:
            start, end = active_range
            roi_confidence = confidence[:, start:end]
            roi_mask = mask_index[:, start:end]
            base_offset = start
        else:
            roi_confidence = confidence
            roi_mask = mask_index
            base_offset = 0
        conf_chunks = torch.chunk(roi_confidence, n_parts, dim=1)
        mask_chunks = torch.chunk(roi_mask, n_parts, dim=1)
        current_chunk_offset = 0
        for conf_c, mask_c in zip(conf_chunks, mask_chunks):
            chunk_len = conf_c.shape[1]
            if chunk_len == 0: continue 
            has_mask_in_chunk = mask_c.any(dim=1)
            max_idx_local = torch.argmax(conf_c, dim=1, keepdim=True)
            local_force = torch.zeros_like(mask_c, dtype=torch.bool)
            local_force.scatter_(1, max_idx_local, True)
            local_force = local_force & has_mask_in_chunk.unsqueeze(1)
            global_start = base_offset + current_chunk_offset
            global_end = global_start + chunk_len
            force_mask[:, global_start : global_end] = local_force
            current_chunk_offset += chunk_len
        transfer_index = transfer_index | force_mask
        transfer_index = transfer_index & mask_index
        return x0, transfer_index
    if num_transfer_tokens is None:
        raise ValueError("num_transfer_tokens must be a tensor when threshold is None.")
    if num_transfer_tokens.dim() == 2 and num_transfer_tokens.size(1) == 1:
        num_transfer_tokens = num_transfer_tokens.squeeze(1)
    num_transfer_tokens = num_transfer_tokens.to(dtype=torch.long, device=confidence.device)
    num_transfer_tokens = torch.clamp(num_transfer_tokens, min=0)
    values, idx = torch.sort(confidence, dim=1, descending=True)
    B, L = confidence.shape
    cols = torch.arange(L, device=confidence.device).unsqueeze(0).expand(B, L)
    k_expanded = num_transfer_tokens.unsqueeze(1).expand(B, L)
    select_sorted = cols < k_expanded
    transfer_int = torch.zeros(B, L, device=confidence.device, dtype=torch.int8)
    transfer_int = transfer_int.scatter(1, idx, select_sorted.to(torch.int8))
    transfer_index = transfer_int.bool() & mask_index 
    return x0, transfer_index

@torch.no_grad()
def generate_with_prefix_cache_adaptive(
    model, prompt, tokenizer=None, steps=128, gen_length=128, 
    min_block_len=1, max_block_len=32,
    metric='entropy',topk_entropy_k=10,
    temperature=0., remasking='low_confidence', mask_id=126336,
    dynamic_threshold_method=None, base_threshold=0.9, min_threshold=0.7,confidence_boost=1.0,
    threshold=None, factor=None, prompt_id="0"
):
    
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    prompt_len = prompt.shape[1]
    total_len = x.shape[1]
    current_idx = prompt_len
    nfe = 0
    block_cnt = 0
    step_ratio = steps / gen_length 
    while current_idx < total_len:
        block_cnt += 1
        x[:, current_idx:] = mask_id 
        output = model(x, use_cache=True)
        logits = output.logits 
        nfe += 1
        next_len = determine_next_block_length(
            logits, 
            start_idx=current_idx, 
            min_len=min_block_len, 
            max_len=max_block_len,
            metric=metric,
            topk_entropy_k=topk_entropy_k
        )
        if current_idx + next_len > total_len:
            next_len = total_len - current_idx
        block_end = current_idx + next_len
        current_steps = max(1, int(next_len * step_ratio))
        past_key_values = output.past_key_values
        new_past_key_values = []
        for i in range(len(past_key_values)): 
            new_past_key_values.append(())
            for j in range(len(past_key_values[i])):
                new_past_key_values[i] += (past_key_values[i][j][:, :, :current_idx],)
        past_key_values = new_past_key_values
        block_mask_index = (x[:, current_idx:block_end] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, current_steps)
        i = 0
        initial_block_entropy = 4.0
        while True:
            if i > 0:
                nfe += 1
                logits = model(x[:, current_idx:], past_key_values=past_key_values, use_cache=True).logits
            else:
                logits = logits[:, current_idx:, :]
            mask_index = (x[:, current_idx:] == mask_id)
            mask_index[:, next_len:] = 0
            if dynamic_threshold_method is not None:
                block_logits = logits[:, :next_len, :]
                block_ids = x[:, current_idx:block_end] 
                block_metric_vals = calculate_metric(block_logits, metric='entropy') 
                is_still_mask = (block_ids == mask_id)
                masked_metric_vals = block_metric_vals[is_still_mask]
                if masked_metric_vals.numel() > 0:
                    avg_val_mask = masked_metric_vals.float().mean().item()
                else:
                    avg_val_mask = 0.0
                if i==0:
                    initial_block_entropy = avg_val_mask
                threshold = get_dynamic_threshold_by_entropy(
                    current_entropy=avg_val_mask,
                    base_threshold=base_threshold,
                    min_threshold=min_threshold,
                    pivot_entropy=initial_block_entropy, 
                    confidence_boost=confidence_boost,
                    method=dynamic_threshold_method
                )
            logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
            x0 = torch.argmax(logits_with_noise, dim=-1) 
            if factor is None:
                x0, transfer_index = get_transfer_index_origin(logits, temperature, remasking, mask_index, 
                                                                x[:, current_idx:], num_transfer_tokens[:, i] if threshold is None else None, threshold)
            else:
                x0, transfer_index = get_transfer_index_dynamic(logits, temperature, remasking, mask_index, 
                                                                x[:, current_idx:], None, factor)
            x[:, current_idx:][transfer_index] = x0[transfer_index]
            i += 1
            if (x[:, current_idx:block_end] == mask_id).sum() == 0:
                break
            if i >= current_steps and threshold is None:
                break
        current_idx = block_end
    return x, nfe

@ torch.no_grad()
def generate_with_prefix_cache(model, prompt, steps=128, gen_length=128, block_length=128, temperature=0.,
             remasking='low_confidence', mask_id=126336, threshold=None, factor=None):
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    assert gen_length % block_length == 0
    num_blocks = gen_length // block_length
    assert steps % num_blocks == 0
    steps = steps // num_blocks
    nfe = 0
    for num_block in range(num_blocks):
        current_block_start = prompt.shape[1] + num_block * block_length
        current_block_end = current_block_start + block_length
        block_mask_index = (x[:, current_block_start:current_block_end] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, steps)
        output = model(x, use_cache=True)
        past_key_values = output.past_key_values
        mask_index = (x == mask_id)
        mask_index[:, current_block_end:] = 0
        if factor is None:
            x0, transfer_index = get_transfer_index_origin(output.logits, temperature, remasking, mask_index, x, num_transfer_tokens[:, 0] if threshold is None else None, threshold)
        else:
            x0, transfer_index = get_transfer_index_dynamic(output.logits, temperature, remasking, mask_index, x, None, factor)
        x[transfer_index] = x0[transfer_index]
        new_past_key_values = []
        for i in range(len(past_key_values)): 
            new_past_key_values.append(())
            for j in range(len(past_key_values[i])):
                new_past_key_values[i] += (past_key_values[i][j][:, :, :current_block_start],)
        past_key_values = new_past_key_values
        nfe += 1
        i = 1
        while True:
            if (x[:, current_block_start:current_block_end] == mask_id).sum() == 0:
                break
            nfe += 1
            mask_index = (x[:, current_block_start:] == mask_id)
            mask_index[:, block_length:] = 0
            logits = model(x[:, current_block_start:], past_key_values=past_key_values, use_cache=True).logits
            logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
            x0 = torch.argmax(logits_with_noise, dim=-1) 
            if factor is None:
                x0, transfer_index = get_transfer_index_origin(logits, temperature, remasking, mask_index, 
                                                                x[:, current_block_start:], num_transfer_tokens[:, i] if threshold is None else None, threshold)
            else:
                x0, transfer_index = get_transfer_index_dynamic(logits, temperature, remasking, mask_index, 
                                                                x[:, current_block_start:], None, factor)
            x[:, current_block_start:][transfer_index] = x0[transfer_index]
            i += 1
    return x, nfe

@torch.no_grad()
def generate_with_prefix_cache_new(model, prompt, steps=128, gen_length=128, block_length=128, temperature=0.,
             remasking='low_confidence', mask_id=126336, threshold=None, factor=None, num_partitions=1):
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    assert gen_length % block_length == 0
    num_blocks = gen_length // block_length
    assert steps % num_blocks == 0
    steps = steps // num_blocks
    nfe = 0
    prompt_len = prompt.shape[1]
    output = model(x[:, :prompt_len], use_cache=True)
    past_key_values = output.past_key_values
    for num_block in range(num_blocks):
        current_block_start = prompt_len + num_block * block_length
        current_block_end = current_block_start + block_length
        block_mask_index = (x[:, current_block_start:current_block_end] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, steps)
        i = 0
        while True:
            nfe += 1
            block_input = x[:, current_block_start:current_block_end]
            outputs = model(block_input, past_key_values=past_key_values, use_cache=True)
            logits = outputs.logits 
            x_local = x[:, current_block_start:current_block_end]
            mask_local = (x_local == mask_id)
            logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
            x0_local = torch.argmax(logits_with_noise, dim=-1)
            if factor is None:
                quota = num_transfer_tokens[:, i] if threshold is None else None
                x0_local, transfer_index_local = get_transfer_index_origin(
                    logits, temperature, remasking, mask_local, 
                    x_local, quota, threshold
                )
            else:
                x0_local, transfer_index_local = get_transfer_index_dynamic(
                    logits, temperature, remasking, mask_local, 
                    x_local, None, factor
                )
            x[:, current_block_start:current_block_end][transfer_index_local] = x0_local[transfer_index_local]
            i += 1
            if (x[:, current_block_start:current_block_end] == mask_id).sum() == 0:
                break
        final_block_input = x[:, current_block_start:current_block_end]
        output = model(final_block_input, past_key_values=past_key_values, use_cache=True)
        past_key_values = output.past_key_values
    return x, nfe

@torch.no_grad()
def generate_with_dual_cache_adaptive(
    model, prompt, tokenizer=None, steps=128, gen_length=128, 
    min_block_len=1, max_block_len=32,
    metric='entropy',topk_entropy_k=10,
    temperature=0., remasking='low_confidence', mask_id=126336,
    dynamic_threshold_method=None, base_threshold=0.9, min_threshold=0.7, confidence_boost=1.0,
    threshold=None, factor=None, prompt_id="0"
):
    x = torch.full((prompt.shape[0], prompt.shape[1] + gen_length), mask_id, dtype=torch.long).to(model.device)
    x[:, :prompt.shape[1]] = prompt.clone()
    prompt_len = prompt.shape[1]
    total_len = x.shape[1]
    current_idx = prompt_len
    nfe = 0
    block_cnt = 0
    step_ratio = steps / gen_length 
    while current_idx < total_len:
        block_cnt += 1
        x[:, current_idx:] = mask_id 
        output = model(x, use_cache=True)
        logits = output.logits 
        nfe += 1
        next_len = determine_next_block_length(
            logits, 
            start_idx=current_idx, 
            min_len=min_block_len, 
            max_len=max_block_len,
            metric=metric,
            topk_entropy_k=topk_entropy_k
        )
        if current_idx + next_len > total_len:
            next_len = total_len - current_idx
        block_end = current_idx + next_len
        current_steps = max(1, int(next_len * step_ratio))
        past_key_values = output.past_key_values
        replace_position = torch.zeros_like(x, dtype=torch.bool)
        replace_position[:, current_idx:block_end] = True
        block_mask_index = (x[:, current_idx:block_end] == mask_id)
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, current_steps)
        i = 0
        initial_block_entropy = 4.0
        while True:
            if i > 0:
                nfe += 1
                logits = model(x[:, current_idx:block_end], past_key_values=past_key_values, use_cache=True,replace_position=replace_position).logits
            else:
                logits = logits[:, current_idx:block_end, :]
            mask_index = (x[:, current_idx:block_end] == mask_id)
            if dynamic_threshold_method is not None:
                block_logits = logits
                block_ids = x[:, current_idx:block_end] 
                block_metric_vals = calculate_metric(block_logits, metric='entropy') 
                is_still_mask = (block_ids == mask_id)
                masked_metric_vals = block_metric_vals[is_still_mask]
                if masked_metric_vals.numel() > 0:
                    avg_val_mask = masked_metric_vals.float().mean().item()
                else:
                    avg_val_mask = 0.0
                if i==0:
                    initial_block_entropy = avg_val_mask
                threshold = get_dynamic_threshold_by_entropy(
                    current_entropy=avg_val_mask,
                    base_threshold=base_threshold,
                    min_threshold=min_threshold,
                    pivot_entropy=initial_block_entropy, 
                    confidence_boost=confidence_boost,
                    method=dynamic_threshold_method
                )
            if factor is None:
                x0_blk, transfer_idx_blk = get_transfer_index_origin(logits, temperature, remasking, mask_index, 
                        x[:, current_idx:block_end], num_transfer_tokens[:, i] if threshold is None else None, threshold)
            else:
                x0_blk, transfer_idx_blk = get_transfer_index_dynamic(logits, temperature, remasking, mask_index, 
                        x[:, current_idx:block_end], None, factor)
            blk_old = x[:, current_idx:block_end]
            blk_new = torch.where(transfer_idx_blk, x0_blk, blk_old)
            x[:, current_idx:block_end] = blk_new
            i += 1
            if (x[:, current_idx:block_end] == mask_id).sum() == 0:
                break
            if i >= current_steps and threshold is None:
                break
        current_idx = block_end
    return x, nfe

@torch.no_grad()
def generate_with_dual_cache(
    model, prompt, steps=128, gen_length=128, block_length=128, temperature=0.,
    remasking="low_confidence", mask_id=126336, threshold=None, factor=None
):
    B = prompt.shape[0]
    Lp = int(prompt.shape[1]) 
    assert gen_length % block_length == 0
    num_blocks = gen_length // block_length
    assert steps % num_blocks == 0
    steps_per_block = steps // num_blocks
    x = torch.full((B, Lp + gen_length), mask_id, dtype=torch.long, device=model.device)
    x[:, :Lp] = prompt
    nfe = 0
    for nb in range(num_blocks):
        s = Lp + nb * block_length
        e = s + block_length
        block_mask_index = (x[:, s:e] == mask_id) 
        num_transfer_tokens = get_num_transfer_tokens(block_mask_index, steps_per_block) 
        out_full = model(x, use_cache=True)
        past_key_values = out_full.past_key_values 
        nfe += 1
        replace_position = torch.zeros_like(x, dtype=torch.bool)
        replace_position[:, s:e] = True 
        global_mask_index = (x == mask_id)
        global_mask_index[:, e:] = False
        if factor is None:
            quota0 = None if threshold is not None else num_transfer_tokens[:, 0] 
            x0, transfer_index = get_transfer_index(
                out_full.logits, temperature, remasking, global_mask_index, x, quota0, threshold
            )
        else:
            x0, transfer_index = get_transfer_index_dynamic(
                out_full.logits, temperature, remasking, global_mask_index, x, None, factor
            )
        x = torch.where(transfer_index, x0, x)
        for i in range(1, steps_per_block):
            if (x[:, s:e] == mask_id).sum() == 0:
                break
            logits_blk = model(
                x[:, s:e], past_key_values=past_key_values, use_cache=True, replace_position=replace_position
            ).logits 
            mask_blk = (x[:, s:e] == mask_id) 
            if factor is None:
                quota_i = None if threshold is not None else num_transfer_tokens[:, i] 
                x0_blk, transfer_idx_blk = get_transfer_index(
                    logits_blk, temperature, remasking, mask_blk, x[:, s:e], quota_i, threshold
                )
            else:
                x0_blk, transfer_idx_blk = get_transfer_index_dynamic(
                    logits_blk, temperature, remasking, mask_blk, x[:, s:e], None, factor
                )
            blk_old = x[:, s:e]
            blk_new = torch.where(transfer_idx_blk, x0_blk, blk_old)
            x[:, s:e] = blk_new 
            nfe += 1
    return x, nfe

def get_transfer_index_entropy(
    logits: torch.Tensor,
    temperature: float,
    remasking: str,
    mask_index: torch.Tensor, 
    x: torch.Tensor, 
    num_transfer_tokens, 
    threshold: float = None,
    min_entropy_confidence: float = 0.85, 
    verbose: bool = True 
):
    logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
    x0 = torch.argmax(logits_with_noise, dim=-1)
    if remasking == "low_confidence":
        p = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.gather(p, dim=-1, index=x0.unsqueeze(-1)).squeeze(-1)
    elif remasking == "random":
        x0_p = torch.rand(x0.shape, device=x0.device, dtype=torch.float64)
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    neg_inf = torch.tensor(float('-inf'), device=x0_p.device, dtype=x0_p.dtype)
    confidence = torch.where(mask_index, x0_p, neg_inf)
    log_p = F.log_softmax(logits.to(torch.float64), dim=-1)
    entropy = -(p * log_p).sum(dim=-1)
    if threshold is not None:
        transfer_index = mask_index & (confidence >= threshold)
        nothing_selected = ~transfer_index.any(dim=1)
        if nothing_selected.any():
            candidate_mask = (confidence >= min_entropy_confidence) & mask_index
            has_candidate = candidate_mask.any(dim=1)
            inf_entropy = torch.tensor(float('inf'), device=entropy.device)
            filtered_entropy = torch.where(candidate_mask, entropy, inf_entropy)
            idx_min_entropy = torch.argmin(filtered_entropy, dim=1)
            idx_max_conf = torch.argmax(confidence, dim=1)
            final_indices = torch.where(has_candidate, idx_min_entropy, idx_max_conf)
            force_mask = torch.zeros_like(transfer_index)
            force_mask.scatter_(1, final_indices.unsqueeze(1), True)
            transfer_index = torch.where(nothing_selected.unsqueeze(1), force_mask, transfer_index)
        transfer_index = transfer_index & mask_index
        return x0, transfer_index
    if num_transfer_tokens is None:
        raise ValueError("num_transfer_tokens must be a tensor when threshold is None.")
    if num_transfer_tokens.dim() == 2 and num_transfer_tokens.size(1) == 1:
        num_transfer_tokens = num_transfer_tokens.squeeze(1)
    num_transfer_tokens = num_transfer_tokens.to(dtype=torch.long, device=confidence.device)
    num_transfer_tokens = torch.clamp(num_transfer_tokens, min=0)
    values, idx = torch.sort(confidence, dim=1, descending=True)
    B, L = confidence.shape
    cols = torch.arange(L, device=confidence.device).unsqueeze(0).expand(B, L)
    k_expanded = num_transfer_tokens.unsqueeze(1).expand(B, L)
    select_sorted = cols < k_expanded
    transfer_int = torch.zeros(B, L, device=confidence.device, dtype=torch.int8)
    transfer_int = transfer_int.scatter(1, idx, select_sorted.to(torch.int8))
    transfer_index = transfer_int.bool() & mask_index
    return x0, transfer_index

def get_transfer_index_leftfirst(
    logits: torch.Tensor,
    temperature: float,
    remasking: str,
    mask_index: torch.Tensor, 
    x: torch.Tensor, 
    num_transfer_tokens, 
    threshold: float = None,
    min_confidence_diff: float = 0.05,
    fallback_k: int = 5 
):
    logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
    x0 = torch.argmax(logits_with_noise, dim=-1) 
    if remasking == "low_confidence":
        p = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.gather(p, dim=-1, index=x0.unsqueeze(-1)).squeeze(-1)
    elif remasking == "random":
        x0_p = torch.rand(x0.shape, device=x0.device, dtype=torch.float64)
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    neg_inf = torch.tensor(torch.finfo(x0_p.dtype).min, device=x0_p.device, dtype=x0_p.dtype)
    confidence = torch.where(mask_index, x0_p, neg_inf) 
    if threshold is not None:
        transfer_index = mask_index & (confidence >= threshold)
        nothing_selected = ~transfer_index.any(dim=1)
        if nothing_selected.any():
            relaxed_threshold = threshold - min_confidence_diff
            curr_k = min(fallback_k, confidence.size(1))
            topk_scores, topk_indices = torch.topk(confidence, k=curr_k, dim=1)
            max_token_indices = topk_indices[:, 0]
            pass_relaxed_mask_k = topk_scores >= relaxed_threshold
            candidates_mask = torch.zeros_like(mask_index)
            candidates_mask.scatter_(1, topk_indices, pass_relaxed_mask_k)
            candidates_mask = candidates_mask & mask_index 
            cumsum_mask = candidates_mask.cumsum(dim=1)
            leftmost_mask = candidates_mask & (cumsum_mask == 1) 
            has_relaxed_candidate = pass_relaxed_mask_k.any(dim=1) 
            leftmost_indices_val = torch.argmax(candidates_mask.int(), dim=1) 
            force_mask = torch.zeros_like(transfer_index)
            force_mask.scatter_(1, max_token_indices.unsqueeze(1), True)
            force_mask = force_mask | leftmost_mask
            transfer_index = torch.where(nothing_selected.unsqueeze(1), force_mask, transfer_index)
        transfer_index = transfer_index & mask_index
        return x0, transfer_index
    if num_transfer_tokens is None:
        raise ValueError("num_transfer_tokens must be a tensor when threshold is None.")
    if num_transfer_tokens.dim() == 2 and num_transfer_tokens.size(1) == 1:
        num_transfer_tokens = num_transfer_tokens.squeeze(1)
    num_transfer_tokens = num_transfer_tokens.to(dtype=torch.long, device=confidence.device)
    num_transfer_tokens = torch.clamp(num_transfer_tokens, min=0)
    values, idx = torch.sort(confidence, dim=1, descending=True)
    B, L = confidence.shape
    cols = torch.arange(L, device=confidence.device).unsqueeze(0).expand(B, L)
    k_expanded = num_transfer_tokens.unsqueeze(1).expand(B, L)
    select_sorted = cols < k_expanded
    transfer_int = torch.zeros(B, L, device=confidence.device, dtype=torch.int8)
    transfer_int = transfer_int.scatter(1, idx, select_sorted.to(torch.int8))
    transfer_index = transfer_int.bool() & mask_index
    return x0, transfer_index

def get_cart_proximity_score(mask_index: torch.Tensor, p: float = 0.5):
    clean_signal = (~mask_index).float().unsqueeze(1) 
    kernel_size = 5 
    decay = torch.tensor([p**(i) for i in range(1, kernel_size//2 + 1)], device=mask_index.device)
    kernel = torch.cat([decay.flip(0), torch.tensor([0.0], device=mask_index.device), decay])
    kernel = kernel.view(1, 1, -1) 
    proximity_score = F.conv1d(
        clean_signal, 
        kernel, 
        padding=kernel_size//2
    ).squeeze(1) 
    return proximity_score

def get_transfer_index_cart(
    logits: torch.Tensor,
    temperature: float,
    remasking: str,
    mask_index: torch.Tensor, 
    x: torch.Tensor, 
    num_transfer_tokens, 
    threshold: float = None,
    cart_lambda: float = 1.0, 
    cart_p: float = 0.5, 
    mask_id: int = 126336
):
    logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
    x0 = torch.argmax(logits_with_noise, dim=-1) 
    if remasking == "low_confidence":
        p = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.gather(p, dim=-1, index=x0.unsqueeze(-1)).squeeze(-1) 
    elif remasking == "random":
        x0_p = torch.rand(x0.shape, device=x0.device, dtype=torch.float64) 
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    neg_inf = torch.tensor(torch.finfo(x0_p.dtype).min, device=x0_p.device, dtype=x0_p.dtype)
    confidence = torch.where(mask_index, x0_p, neg_inf) 
    if threshold is not None:
        transfer_index = mask_index & (confidence >= threshold)
        num_selected = transfer_index.sum(dim=1)
        needs_fallback = (num_selected == 0)
        if needs_fallback.any():
            real_global_mask = (x == mask_id) 
            prox_score = get_cart_proximity_score(real_global_mask, p=cart_p)
            mixed_score = confidence + (cart_lambda * prox_score)
            fallback_indices = torch.argmax(mixed_score, dim=1, keepdim=True)
            force_mask = torch.zeros_like(transfer_index)
            force_mask.scatter_(1, fallback_indices, True)
            transfer_index = torch.where(
                needs_fallback.unsqueeze(-1),
                force_mask,
                transfer_index
            )
        transfer_index = transfer_index & mask_index
        return x0, transfer_index
    if num_transfer_tokens is None:
        raise ValueError("num_transfer_tokens must be a tensor when threshold is None.")
    if num_transfer_tokens.dim() == 2 and num_transfer_tokens.size(1) == 1:
        num_transfer_tokens = num_transfer_tokens.squeeze(1)
    num_transfer_tokens = num_transfer_tokens.to(dtype=torch.long, device=confidence.device)
    num_transfer_tokens = torch.clamp(num_transfer_tokens, min=0)
    values, idx = torch.sort(confidence, dim=1, descending=True) 
    B, L = confidence.shape
    cols = torch.arange(L, device=confidence.device).unsqueeze(0).expand(B, L) 
    k_expanded = num_transfer_tokens.unsqueeze(1).expand(B, L) 
    select_sorted = cols < k_expanded 
    transfer_int = torch.zeros(B, L, device=confidence.device, dtype=torch.int8) 
    transfer_int = transfer_int.scatter(1, idx, select_sorted.to(torch.int8))
    transfer_index = transfer_int.bool() & mask_index 
    return x0, transfer_index

def get_transfer_index_origin(
    logits: torch.Tensor,
    temperature: float,
    remasking: str,
    mask_index: torch.Tensor, 
    x: torch.Tensor, 
    num_transfer_tokens, 
    threshold: float = None,
):
    logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
    x0 = torch.argmax(logits_with_noise, dim=-1) 
    if remasking == "low_confidence":
        p = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.gather(p, dim=-1, index=x0.unsqueeze(-1)).squeeze(-1) 
    elif remasking == "random":
        x0_p = torch.rand(x0.shape, device=x0.device, dtype=torch.float64) 
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    neg_inf = torch.tensor(torch.finfo(x0_p.dtype).min, device=x0_p.device, dtype=x0_p.dtype)
    confidence = torch.where(mask_index, x0_p, neg_inf) 
    if threshold is not None:
        transfer_index = mask_index & (confidence >= threshold)
        max_conf_indices = torch.argmax(confidence, dim=1, keepdim=True) 
        force_mask = torch.zeros_like(transfer_index).scatter_(1, max_conf_indices, True)
        transfer_index = transfer_index | force_mask
        transfer_index = transfer_index & mask_index
        return x0, transfer_index
    if num_transfer_tokens is None:
        raise ValueError("num_transfer_tokens must be a tensor when threshold is None.")
    if num_transfer_tokens.dim() == 2 and num_transfer_tokens.size(1) == 1:
        num_transfer_tokens = num_transfer_tokens.squeeze(1)
    num_transfer_tokens = num_transfer_tokens.to(dtype=torch.long, device=confidence.device)
    num_transfer_tokens = torch.clamp(num_transfer_tokens, min=0)
    values, idx = torch.sort(confidence, dim=1, descending=True) 
    B, L = confidence.shape
    cols = torch.arange(L, device=confidence.device).unsqueeze(0).expand(B, L) 
    k_expanded = num_transfer_tokens.unsqueeze(1).expand(B, L) 
    select_sorted = cols < k_expanded 
    transfer_int = torch.zeros(B, L, device=confidence.device, dtype=torch.int8) 
    transfer_int = transfer_int.scatter(1, idx, select_sorted.to(torch.int8))
    transfer_index = transfer_int.bool() & mask_index 
    return x0, transfer_index

def get_transfer_index_dynamic(logits, temperature, remasking, mask_index, x, num_transfer_tokens, factor=1):
    logits_with_noise = add_gumbel_noise(logits, temperature=temperature)
    x0 = torch.argmax(logits_with_noise, dim=-1) 
    if remasking == 'low_confidence':
        p = F.softmax(logits.to(torch.float64), dim=-1)
        x0_p = torch.squeeze(
            torch.gather(p, dim=-1, index=torch.unsqueeze(x0, -1)), -1) 
    elif remasking == 'random':
        x0_p = torch.rand((x0.shape[0], x0.shape[1]), device=x0.device)
    else:
        raise NotImplementedError(remasking)
    x0 = torch.where(mask_index, x0, x)
    confidence = torch.where(mask_index, x0_p, -np.inf)
    transfer_index = torch.zeros_like(x0, dtype=torch.bool, device=x0.device)
    num_transfer_tokens = mask_index.sum(dim=1, keepdim=True) 
    for j in range(confidence.shape[0]):
        num_tokens = int(num_transfer_tokens[j].item())
        if num_tokens == 0:
            continue
        ns=list(range(1,num_transfer_tokens[j]+1))
        es=[factor/(n+1) for n in ns]
        threshs=[1-e for e in es] 
        threshs[0]=-1
        sorted_confidence=torch.sort(confidence[j][mask_index[j]],dim=-1,descending=True)[0]
        assert len(sorted_confidence)==len(threshs)
        for top_i in range(len(threshs)):
            if sorted_confidence[top_i]<threshs[top_i]:
                break
        if top_i == 0 or top_i == len(threshs)-1:
            top_i+=1
        _, select_index = torch.topk(confidence[j], k=top_i)
        transfer_index[j, select_index] = True
    return x0, transfer_index

def main():
    device = 'cuda'
    model = LLaDAModelLM.from_pretrained('GSAI-ML/LLaDA-8B-Instruct', trust_remote_code=True, torch_dtype=torch.bfloat16).to(device).eval()
    tokenizer = AutoTokenizer.from_pretrained('GSAI-ML/LLaDA-8B-Instruct', trust_remote_code=True)
    prompt = "Lily can run 12 kilometers per hour for 4 hours. After that, she runs 6 kilometers per hour. How many kilometers can she run in 8 hours?"
    m = [{"role": "user", "content": prompt}, ]
    prompt = tokenizer.apply_chat_template(m, add_generation_prompt=True, tokenize=False)
    input_ids = tokenizer(prompt)['input_ids']
    input_ids = torch.tensor(input_ids).to(device).unsqueeze(0)
    with torch.inference_mode():
        nvtx.range_push("INFER")
        out = generate_with_dual_cache(model, input_ids, steps=128, gen_length=128, block_length=32, temperature=0., remasking='low_confidence')
        torch.cuda.synchronize()
        nvtx.range_pop()

if __name__ == '__main__':
    main()