import warnings
import copy
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple, Union

import numpy as np
import math
import torch
import torch.distributions as dists
from torch.nn import functional as F
from transformers import __version__
from transformers.generation.configuration_utils import (
    GenerationConfig
)
from transformers.utils import (
    ModelOutput,
    is_torchdynamo_compiling,
    logging,
)

logger = logging.get_logger(__name__)

def get_num_transfer_tokens(mask_index, steps):
    mask_num = mask_index.sum(dim=1, keepdim=True)
    base = mask_num // steps
    remainder = mask_num % steps
    num_transfer_tokens = torch.zeros(mask_num.size(0), steps, device=mask_index.device, dtype=torch.int64) + base
    for i in range(mask_num.size(0)):
        num_transfer_tokens[i, :remainder[i]] += 1
    return num_transfer_tokens

def top_p_logits(logits, top_p=None):
    sorted_logits, sorted_indices = torch.sort(logits, descending=True)
    cumulative_probs = torch.cumsum(F.softmax(sorted_logits, dim=-1), dim=-1)
    sorted_indices_to_remove = cumulative_probs > top_p
    sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
    sorted_indices_to_remove[..., 0] = 0
    mask = torch.zeros_like(logits, dtype=torch.bool, device=logits.device)
    mask = mask.scatter_(-1, sorted_indices, sorted_indices_to_remove)
    logits = logits.masked_fill(mask, torch.finfo(logits.dtype).min)
    return logits

def top_k_logits(logits, top_k=None):
    top_k = min(top_k, logits.size(-1))
    indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
    logits = logits.masked_fill(indices_to_remove, torch.finfo(logits.dtype).min)
    return logits

def sample_tokens(logits, temperature=0.0, top_p=None, top_k=None, margin_confidence=False, neg_entropy=False):
    if temperature > 0:
        logits = logits / temperature
    if top_p is not None and top_p < 1:
        logits = top_p_logits(logits, top_p)
    if top_k is not None:
        logits = top_k_logits(logits, top_k)
    probs = torch.softmax(logits, dim=-1)

    if temperature > 0:
        try:
            x0 = dists.Categorical(probs=probs).sample()
            confidence = torch.gather(probs, -1, x0.unsqueeze(-1)).squeeze(-1)
        except:
            confidence, x0 = probs.max(dim=-1)
    else:
        confidence, x0 = probs.max(dim=-1)
    
    if margin_confidence:
        sorted_probs, _ = torch.sort(probs, dim=-1, descending=True)
        top1_probs = sorted_probs[:, 0] 
        top2_probs = sorted_probs[:, 1] 
        confidence = top1_probs - top2_probs 
    
    if neg_entropy:
        epsilon = 1e-10
        log_probs = torch.log(probs + epsilon)
        confidence = torch.sum(probs * log_probs, dim=-1)
    
    return confidence, x0

def get_dynamic_threshold_by_entropy(
    current_entropy, 
    base_threshold=0.9, 
    min_threshold=.0, 
    pivot_entropy=1.5, 
    confidence_boost=1.0, 
    method='linear'
): 
    if current_entropy < 0: current_entropy = 0
    raw_ratio = min(current_entropy / pivot_entropy, 1.0)

    if confidence_boost > 1.0:
        ratio = raw_ratio * confidence_boost - (confidence_boost - 1.0)
        ratio = max(0.0, ratio)
    else:
        ratio = raw_ratio

    if method == 'linear':
        factor = ratio
    elif method == 'square':
        factor = ratio ** 2
    elif method == 'cubic':
        factor = ratio ** 3
    elif method == 'sqrt':
        factor = math.sqrt(ratio)
    elif method == 'sigmoid':
        factor = 0.5 * (1 - math.cos(ratio * math.pi))
    elif method == 'step':
        if ratio > 0.8: factor = 1.0
        elif ratio > 0.4: factor = 0.7
        else: factor = 0.0
    elif method == 'power_decay':
        factor = math.pow(raw_ratio, confidence_boost)
    elif method == 'sine':
        factor = math.sin(ratio * (math.pi / 2))
    elif method == 'elliptical':
        factor = math.sqrt(1 - (1 - ratio) ** 2)
    elif method == 'exp':
        k = max(confidence_boost, 0.1) 
        numerator = 1 - math.exp(-k * ratio)
        denominator = 1 - math.exp(-k)
        factor = numerator / denominator
    elif method == 'log':
        k = max(confidence_boost, 0.1)
        factor = math.log(1 + k * ratio) / math.log(1 + k)
    else:
        raise ValueError(f"Unknown method: {method}")

    delta = base_threshold - min_threshold
    dynamic_threshold = min_threshold + delta * factor
    
    return dynamic_threshold

@dataclass
class DreamModelOutput(ModelOutput):
    sequences: torch.LongTensor = None
    history: Optional[Tuple[torch.FloatTensor]] = None

class DreamGenerationConfig(GenerationConfig):
    def __init__(self, **kwargs):
        self.temperature: float = kwargs.pop("temperature", 0.0)
        self.top_p: Optional[float] = kwargs.pop("top_p", None)
        self.top_k: Optional[int] = kwargs.pop("top_k", None)
        self.max_length = kwargs.pop("max_length", 20)
        self.max_new_tokens = kwargs.pop("max_new_tokens", None)
        self.eps: float = kwargs.pop("eps", 1e-3)
        self.steps: int = kwargs.pop("steps", 512)
        self.alg: str = kwargs.pop("alg", 'origin')
        self.alg_temp: Optional[float] = kwargs.pop("alg_temp", None)
        self.num_return_sequences: int = kwargs.pop("num_return_sequences", 1)
        self.return_dict_in_generate: bool = kwargs.pop("return_dict_in_generate", False)
        self.output_history: bool = kwargs.pop("output_history", False)
        self.mask_token_id = kwargs.pop("mask_token_id", None)
        self.pad_token_id = kwargs.pop("pad_token_id", None)
        self.bos_token_id = kwargs.pop("bos_token_id", None)
        self.eos_token_id = kwargs.pop("eos_token_id", None)
        self.generation_kwargs = kwargs.pop("generation_kwargs", {})
        self._from_model_config = kwargs.pop("_from_model_config", False)
        self._commit_hash = kwargs.pop("_commit_hash", None)
        self.transformers_version = kwargs.pop("transformers_version", __version__)

        if not self._from_model_config:
            for key, value in kwargs.items():
                try:
                    setattr(self, key, value)
                except AttributeError as err:
                    logger.error(f"Can't set {key} with value {value} for {self}")
                    raise err

        self.validate(is_init=True)

    def validate(self, is_init=False):
        pass

def print_uncertainty_snapshot(step, logits, current_ids, prompt_length, tokenizer, mask_token_id, block_start=None, block_end=None):
    sample_logits = logits[0] 
    sample_ids = current_ids[0]
    
    start_pos = prompt_length
    end_pos = sample_ids.shape[0]
    
    if block_start is not None and block_end is not None:
        start_pos = max(prompt_length, block_start)
        end_pos = min(sample_ids.shape[0], block_end)

    target_logits = sample_logits[start_pos:end_pos]
    probs = torch.softmax(target_logits, dim=-1)

    log_probs = torch.log(probs + 1e-9)
    entropy = -torch.sum(probs * log_probs, dim=-1)

    topk_probs, topk_indices = torch.topk(probs, k=5, dim=-1)

    for i in range(end_pos - start_pos):
        abs_pos = start_pos + i
        token_id = sample_ids[abs_pos].item()
        
        if token_id == mask_token_id:
            token_str = "[MASK]"
        else:
            token_str = tokenizer.decode([token_id]).strip()
            if len(token_str) > 10: token_str = token_str[:8] + ".."
        
        ent_val = entropy[i].item()

        top_preds_str = ""
        for k in range(5):
            pred_id = topk_indices[i, k].item()
            pred_prob = topk_probs[i, k].item()
            pred_word = tokenizer.decode([pred_id]).strip()
            pred_word = pred_word.replace('\n', '\\n').replace('\r', '')
            top_preds_str += f"{pred_word}({pred_prob:.2f}) "

def calculate_metric(logits, metric='entropy', topk_entropy_k=10):
    logits = logits.float()
    probs = F.softmax(logits, dim=-1)
    
    if metric == 'entropy':
        log_probs = F.log_softmax(logits, dim=-1)
        return -torch.sum(probs * log_probs, dim=-1)

    elif metric == 'confidence':
        max_probs, _ = torch.max(probs, dim=-1)
        return 1.0 - max_probs

    elif metric == 'varentropy':
        log_probs = F.log_softmax(logits, dim=-1)
        entropy = -torch.sum(probs * log_probs, dim=-1, keepdim=True)
        diff_sq = (log_probs + entropy) ** 2
        return torch.sum(probs * diff_sq, dim=-1)

    elif metric == 'gap':
        top2_vals, _ = torch.topk(probs, k=2, dim=-1)
        return 1.0 - (top2_vals[..., 0] - top2_vals[..., 1])

    elif metric == 'gini':
        return 1.0 - torch.sum(probs ** 2, dim=-1)
    
    elif metric == 'topk_entropy':
        topk_probs, _ = torch.topk(probs, k=topk_entropy_k, dim=-1)
        sum_probs = topk_probs.sum(dim=-1, keepdim=True)
        topk_probs = topk_probs / (sum_probs + 1e-10)
        return -torch.sum(topk_probs * torch.log(topk_probs + 1e-10), dim=-1)

    else:
        raise ValueError(f"Unknown metric: {metric}")

def get_max_entropy_jump_pos_clean(logits, search_start, search_end, metric='entropy', topk_entropy_k=10):
    seq_len = logits.shape[1]
    
    if search_start >= seq_len:
        return search_start, 0.0
    search_end = min(search_end, seq_len)
    
    if search_start >= search_end:
        return search_start, 0.0

    calc_start = max(0, search_start - 1)
    calc_end = search_end
    
    slice_logits = logits[:, calc_start:calc_end, :]
    
    local_metric_tensor = calculate_metric(slice_logits, metric=metric, topk_entropy_k=topk_entropy_k)
    local_vals = local_metric_tensor[0].float().cpu().numpy()
    
    if search_start > 0:
        curr_vals = local_vals[1:]
        prev_vals = local_vals[:-1]
        diffs = curr_vals - prev_vals
    else:
        padded_vals = np.concatenate(([0.0], local_vals))
        diffs = padded_vals[1:] - padded_vals[:-1]

    if len(diffs) == 0:
        return search_start, 0.0
        
    best_idx = np.argmax(diffs)
    max_val = diffs[best_idx]
    
    best_pos = search_start + best_idx
            
    return int(best_pos), float(max_val)

def determine_next_block_length(logits, start_idx, min_len=8, max_len=32, metric='entropy',topk_entropy_k=10):
    seq_len = logits.shape[1]
    
    search_start = start_idx + min_len
    search_end = min(start_idx + max_len, seq_len)
    
    if search_start >= seq_len:
        return seq_len - start_idx

    best_jump_pos, jump_val = get_max_entropy_jump_pos_clean(
        logits, 
        search_start=search_start, 
        search_end=search_end, 
        metric=metric,
        topk_entropy_k=topk_entropy_k
    )   
    
    if jump_val < 0.01:
        relative_jump = search_end - start_idx
    else:
        relative_jump = best_jump_pos - start_idx

    decision = relative_jump
    return min(decision, max_len)

class DreamGenerationMixin:
    @staticmethod
    def _expand_inputs_for_generation(
        expand_size: int = 1,
        input_ids: Optional[torch.LongTensor] = None,
        attention_mask: Optional[torch.LongTensor] = None
    ) -> Tuple[torch.LongTensor, Dict[str, Any]]:
        if expand_size == 1:
            return input_ids, attention_mask
        if input_ids is not None:
            input_ids = input_ids.repeat_interleave(expand_size, dim=0)
        if attention_mask is not None:
            attention_mask = attention_mask.repeat_interleave(expand_size, dim=0)
        return input_ids, attention_mask

    def _validate_generated_length(self, generation_config, input_ids_length, has_default_max_length):
        if is_torchdynamo_compiling():
            return

        if has_default_max_length and generation_config.max_new_tokens is None and generation_config.max_length == 20:
            warnings.warn(
                f"Using the model-agnostic default `max_length` (={generation_config.max_length}) to control the "
                "generation length. We recommend setting `max_new_tokens` to control the maximum length of the "
                "generation.",
                UserWarning,
            )
        if input_ids_length >= generation_config.max_length:
            input_ids_string = "input_ids"
            raise ValueError(
                f"Input length of {input_ids_string} is {input_ids_length}, but `max_length` is set to"
                f" {generation_config.max_length}. This can lead to unexpected behavior. You should consider"
                " increasing `max_length` or, better yet, setting `max_new_tokens`."
            )

    def _prepare_generated_length(
        self,
        generation_config,
        has_default_max_length,
        input_ids_length,
    ):
        if generation_config.max_new_tokens is not None:
            if not has_default_max_length and generation_config.max_length is not None:
                logger.warning(
                    f"Both `max_new_tokens` (={generation_config.max_new_tokens}) and `max_length`(="
                    f"{generation_config.max_length}) seem to have been set. `max_new_tokens` will take precedence. "
                    "Please refer to the documentation for more information. "
                    "(https://huggingface.co/docs/transformers/main/en/main_classes/text_generation)"
                )
            generation_config.max_length = generation_config.max_new_tokens + input_ids_length

        elif has_default_max_length:
            if generation_config.max_length == DreamGenerationConfig().max_length:
                generation_config.max_length = generation_config.max_length + input_ids_length
                max_position_embeddings = getattr(self.config, "max_position_embeddings", None)
                if max_position_embeddings is not None:
                    generation_config.max_length = min(generation_config.max_length, max_position_embeddings)

        return generation_config

    def _prepare_generation_config(
        self, generation_config: Optional[DreamGenerationConfig], **kwargs: Dict
    ) -> DreamGenerationConfig:
        using_model_generation_config = False
        if generation_config is None:
            generation_config = DreamGenerationConfig.from_model_config(self.config)
            using_model_generation_config = True

        if not is_torchdynamo_compiling():
            generation_config = copy.deepcopy(generation_config)
            _kwargs = generation_config.update(**kwargs)
            if not using_model_generation_config:
                if generation_config.bos_token_id is None:
                    generation_config.bos_token_id = self.generation_config.bos_token_id
                if generation_config.eos_token_id is None:
                    generation_config.eos_token_id = self.generation_config.eos_token_id
                if generation_config.pad_token_id is None:
                    generation_config.pad_token_id = self.generation_config.pad_token_id
                if generation_config.mask_token_id is None:
                    generation_config.mask_token_id = self.generation_config.mask_token_id

        return generation_config

    def _prepare_special_tokens(
        self,
        generation_config: DreamGenerationConfig,
        device: Optional[Union[torch.device, str]] = None,
    ):
        def _tensor_or_none(token, device=None):
            if token is None:
                return token

            device = device if device is not None else self.device
            if isinstance(token, torch.Tensor):
                return token.to(device)
            return torch.tensor(token, device=device, dtype=torch.long)

        bos_token_tensor = _tensor_or_none(generation_config.bos_token_id, device=device)
        eos_token_tensor = _tensor_or_none(generation_config.eos_token_id, device=device)
        pad_token_tensor = _tensor_or_none(generation_config.pad_token_id, device=device)
        mask_token_tensor = _tensor_or_none(generation_config.mask_token_id, device=device)

        if eos_token_tensor is not None and eos_token_tensor.ndim == 0:
            eos_token_tensor = eos_token_tensor.unsqueeze(0)

        if pad_token_tensor is None and eos_token_tensor is not None:
            pad_token_tensor = eos_token_tensor[0]
            logger.warning(f"Setting `pad_token_id` to `eos_token_id`:{pad_token_tensor} for open-end generation.")

        generation_config._bos_token_tensor = bos_token_tensor
        generation_config._eos_token_tensor = eos_token_tensor
        generation_config._pad_token_tensor = pad_token_tensor
        generation_config._mask_token_tensor = mask_token_tensor

    @torch.no_grad()
    def diffusion_generate(
        self,
        inputs: Optional[torch.Tensor] = None,
        generation_config: Optional[DreamGenerationConfig] = None,
        **kwargs,
    ) -> Union[DreamModelOutput, torch.LongTensor]:
        generation_config = self._prepare_generation_config(generation_config, **kwargs)

        assert inputs is not None
        input_ids = inputs
        device = input_ids.device
        attention_mask = kwargs.pop("attention_mask", None)
        self._prepare_special_tokens(generation_config, device=device)

        input_ids_length = input_ids.shape[-1]
        has_default_max_length = kwargs.get("max_length") is None and generation_config.max_length is not None
        generation_config = self._prepare_generated_length(
            generation_config=generation_config,
            has_default_max_length=has_default_max_length,
            input_ids_length=input_ids_length,
        )

        self._validate_generated_length(generation_config, input_ids_length, has_default_max_length)
        
        if not is_torchdynamo_compiling() and self.device.type != input_ids.device.type:
            warnings.warn(
                "You are calling .generate() with the `input_ids` being on a device type different"
                f" than your model's device. `input_ids` is on {input_ids.device.type}, whereas the model"
                f" is on {self.device.type}. You may experience unexpected behaviors or slower generation."
                " Please make sure that you have put `input_ids` to the"
                f" correct device by calling for example input_ids = input_ids.to('{self.device.type}') before"
                " running `.generate()`.",
                UserWarning,
            )
        if (
            hasattr(generation_config, "pad_token_id") and
            torch.any(input_ids == generation_config.pad_token_id) and 
            attention_mask is None
        ):
            warnings.warn(
                "Padding was detected but no attention mask is passed here. For correct "
                "generation results, please set `attention_mask` when batch-padding inputs.",
                UserWarning,
            )

        input_ids, attention_mask = self._expand_inputs_for_generation(
            expand_size=generation_config.num_return_sequences,
            input_ids=input_ids,
            attention_mask=attention_mask 
        )
        threshold = kwargs.get("threshold", 0.9)
        block_length = kwargs.get("block_length", 32)
        dual_cache = kwargs.get("dual_cache", False)
        use_cache = kwargs.get("use_cache", False)

        adaptive = kwargs.get("adaptive", False)
        min_block_len = kwargs.get("min_block_len", 1)
        max_block_len = kwargs.get("max_block_len", 32)
        metric = kwargs.get("metric", 'entropy')
        topk_entropy_k = kwargs.get("topk_entropy_k", 10)
        
        dynamic_threshold_method = kwargs.get("dynamic_threshold_method", None)
        base_threshold = kwargs.get("base_threshold", 0.9)
        min_threshold = kwargs.get("min_threshold", 0.0)
        confidence_boost = kwargs.get("confidence_boost", 0.0)

        if adaptive:
            if use_cache:
                result = self._sample_adaptive(
                    input_ids,
                    attention_mask=attention_mask,
                    generation_config=generation_config,
                    threshold=threshold,
                    min_block_len=min_block_len,
                    max_block_len=max_block_len,
                    metric=metric,
                    topk_entropy_k=topk_entropy_k,
                    dual_cache=dual_cache,
                    dynamic_threshold_method=dynamic_threshold_method,
                    base_threshold=base_threshold,
                    min_threshold=min_threshold,
                    confidence_boost=confidence_boost,
                )
            else:
                result = self._sample_no_cache_adaptive(
                    input_ids,
                    attention_mask=attention_mask,
                    generation_config=generation_config,
                    threshold=threshold,
                    min_block_len=min_block_len,
                    max_block_len=max_block_len,
                    metric=metric,
                    topk_entropy_k=topk_entropy_k,
                    dynamic_threshold_method=dynamic_threshold_method,
                    base_threshold=base_threshold,
                    min_threshold=min_threshold,
                    confidence_boost=confidence_boost,
                )
        else:
            if use_cache:
                result = self._sample(
                    input_ids,
                    attention_mask=attention_mask,
                    generation_config=generation_config,
                    threshold=threshold,
                    block_length=block_length,
                    dual_cache=dual_cache
                )
            else:
                result = self._sample_no_cache(
                    input_ids,
                    attention_mask=attention_mask,
                    generation_config=generation_config,
                    threshold=threshold,
                    block_length=block_length,
                )

        return result

    def _sample_no_cache_adaptive(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.LongTensor],
        generation_config: DreamGenerationConfig,
        threshold: Optional[float] = 0.9,
        min_block_len:Optional[int] = 1,
        max_block_len:Optional[int] = 32,
        metric:Optional[str] = 'entropy',
        topk_entropy_k:Optional[int] = 10,
        dynamic_threshold_method:Optional[str] = None,
        base_threshold:float = 0.9,
        min_threshold:float = 0.0,
        confidence_boost:float = 0.0,
    ) -> Union[DreamModelOutput, torch.LongTensor]:
        output_history = generation_config.output_history
        return_dict_in_generate = generation_config.return_dict_in_generate
        max_length = generation_config.max_length
        mask_token_id = generation_config.mask_token_id
        steps = generation_config.steps
        temperature = generation_config.temperature
        top_p = generation_config.top_p
        top_k = generation_config.top_k
        alg = generation_config.alg
        alg_temp = generation_config.alg_temp

        histories = [] if (return_dict_in_generate and output_history) else None

        x = F.pad(input_ids, (0, max_length - input_ids.shape[1]), value=mask_token_id)
        gen_length = max_length - input_ids.shape[1]
        
        if attention_mask is not None and torch.any(attention_mask == 0.0):
            attention_mask = F.pad(attention_mask, (0, max_length - attention_mask.shape[1]), value=1.0)
            tok_idx = attention_mask.long().cumsum(-1) - 1
            tok_idx.masked_fill_(attention_mask == 0, 1)
            attention_mask = torch.logical_and(
                attention_mask.unsqueeze(1).unsqueeze(-2),
                attention_mask.unsqueeze(1).unsqueeze(-1),
            )
        else:
            tok_idx = None
            attention_mask = "full"

        nfe=0
        prompt_len = input_ids.shape[1]
        current_block_start = prompt_len

        while current_block_start < max_length:
            
            model_output = self(x, attention_mask, tok_idx, use_cache=False)
            logits = model_output.logits
            logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)
            nfe += 1

            this_block_len = determine_next_block_length(
                logits, 
                start_idx=current_block_start,
                min_len=min_block_len,
                max_len=max_block_len,
                metric=metric,
                topk_entropy_k=topk_entropy_k
            )

            current_block_end = min(current_block_start + this_block_len, max_length)
            actual_block_len = current_block_end - current_block_start

            i = 0
            initial_block_entropy = 4.0

            while True:
                if i > 0:
                    model_output = self(x, attention_mask, tok_idx, use_cache=False)
                    logits = model_output.logits
                    logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)
                    nfe += 1
                
                if dynamic_threshold_method is not None:
                    block_logits = logits[:, current_block_start:current_block_end, :]
                    block_ids = x[:, current_block_start:current_block_end] 
                    block_metric_vals = calculate_metric(block_logits, metric='entropy') 
                    is_still_mask = (block_ids == mask_token_id)
                    masked_metric_vals = block_metric_vals[is_still_mask]
                    
                    if masked_metric_vals.numel() > 0:
                        avg_val_mask = masked_metric_vals.float().mean().item()
                    else:
                        avg_val_mask = 0.0

                    if i==0:
                        initial_block_entropy = avg_val_mask

                    threshold = get_dynamic_threshold_by_entropy(
                        current_entropy=avg_val_mask,
                        base_threshold=base_threshold,
                        min_threshold=min_threshold,
                        pivot_entropy=initial_block_entropy,
                        confidence_boost=confidence_boost,
                        method=dynamic_threshold_method
                    )

                mask_index = (x[:, current_block_start:current_block_end] == mask_token_id)
                                
                current_block_logits = logits[:, current_block_start:current_block_end]
                mask_logits = current_block_logits[mask_index]
                confidence, x0 = sample_tokens(mask_logits, temperature=temperature, top_p=top_p, top_k=top_k)
                
                x_ = torch.zeros_like(x[:, current_block_start:current_block_end], device=self.device, dtype=torch.long) + mask_token_id
                full_confidence = torch.full_like(x[:, current_block_start:current_block_end], -torch.inf, device=self.device, dtype=logits.dtype)
                
                x_[mask_index] = x0.clone()
                full_confidence[mask_index] = confidence
                
                current_transfer_tokens = (x[:, current_block_start:current_block_end] == mask_token_id).sum()
                
                selected_confidence, select_index = torch.topk(full_confidence, current_transfer_tokens)
                transfer_index = torch.zeros_like(x_, device=x.device, dtype=torch.bool)
                
                select_index = select_index.to(x.device)
                transfer_index[0, select_index[0]] = True
                if current_transfer_tokens > 0:
                    for k in range(1, current_transfer_tokens):
                        if selected_confidence[0, k] < threshold:
                            transfer_index[0, select_index[0, k]] = False
                x[:, current_block_start:current_block_end][transfer_index] = x_[transfer_index]

                i += 1

                if (x[:, current_block_start:current_block_end] == mask_token_id).sum() == 0:
                    break

            current_block_start=current_block_end

        if return_dict_in_generate:
            return {
                "sequences": x,
                "history": histories,
                "nfe": nfe
            }
        else:
            return x

    def _sample_adaptive(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.LongTensor],
        generation_config: DreamGenerationConfig,
        threshold: Optional[float] = 0.9,
        min_block_len:Optional[int] = 1,
        max_block_len:Optional[int] = 32,
        metric:Optional[str] = 'entropy',
        topk_entropy_k:Optional[int] = 10,
        dual_cache: Optional[bool] = False,
        dynamic_threshold_method:Optional[str] = None,
        base_threshold:float = 0.9,
        min_threshold:float = 0.0,
        confidence_boost:float = 0.0,
    ) -> Union[DreamModelOutput, torch.LongTensor]:
        output_history = generation_config.output_history
        return_dict_in_generate = generation_config.return_dict_in_generate
        max_length = generation_config.max_length
        mask_token_id = generation_config.mask_token_id
        steps = generation_config.steps
        temperature = generation_config.temperature
        top_p = generation_config.top_p
        top_k = generation_config.top_k
        alg = generation_config.alg
        alg_temp = generation_config.alg_temp

        histories = [] if (return_dict_in_generate and output_history) else None

        x = F.pad(input_ids, (0, max_length - input_ids.shape[1]), value=mask_token_id)
        gen_length = max_length - input_ids.shape[1]
        
        if attention_mask is not None and torch.any(attention_mask == 0.0):
            attention_mask = F.pad(attention_mask, (0, max_length - attention_mask.shape[1]), value=1.0)
            tok_idx = attention_mask.long().cumsum(-1) - 1
            tok_idx.masked_fill_(attention_mask == 0, 1)
            attention_mask = torch.logical_and(
                attention_mask.unsqueeze(1).unsqueeze(-2),
                attention_mask.unsqueeze(1).unsqueeze(-1),
            )
        else:
            tok_idx = None
            attention_mask = "full"

        nfe=0
        prompt_len = input_ids.shape[1]
        current_block_start = prompt_len

        past_key_values = None

        while current_block_start < max_length:
            
            model_output = self(x, attention_mask, tok_idx, use_cache=True)
            past_key_values = model_output.past_key_values
            logits = model_output.logits
            logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)
            nfe += 1

            this_block_len = determine_next_block_length(
                logits, 
                start_idx=current_block_start,
                min_len=min_block_len,
                max_len=max_block_len,
                metric=metric,
                topk_entropy_k=topk_entropy_k
            )

            current_block_end = min(current_block_start + this_block_len, max_length)
            actual_block_len = current_block_end - current_block_start

            confidence, x0 = sample_tokens(logits, temperature=temperature, top_p=top_p, top_k=top_k)
            x[:, current_block_start] = x0[:, current_block_start]

            if not dual_cache:
                new_past_key_values = []
                for i in range(len(past_key_values)):
                    new_past_key_values.append(())
                    for j in range(len(past_key_values[i])):
                        new_past_key_values[i] += (past_key_values[i][j][:, :current_block_start, :],)
                past_key_values = new_past_key_values
            else:
                replace_position = torch.zeros_like(x, dtype=torch.bool)
                replace_position[:, current_block_start:current_block_end] = 1

            initial_block_entropy = 4.0

            i = 1
            while True:
                if (x[:, current_block_start:current_block_end] == mask_token_id).sum() == 0:
                    break


                if dual_cache:
                    model_output = self(x[:, current_block_start:current_block_end], attention_mask, 
                                        tok_idx[:, current_block_start:current_block_end] if tok_idx is not None else None, 
                                        past_key_values=past_key_values, use_cache=True, dual_cache=dual_cache, replace_position=replace_position)
                else:
                    model_output = self(x[:, current_block_start:], attention_mask, 
                                        tok_idx[:, current_block_start:] if tok_idx is not None else None, 
                                        past_key_values=past_key_values, use_cache=True)
                logits = model_output.logits
                logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)
                nfe += 1

                if dual_cache:
                    mask_index = (x[:, current_block_start:current_block_end] == mask_token_id)
                else:
                    mask_index = (x[:, current_block_start:] == mask_token_id)

                if dynamic_threshold_method is not None:
                    if dual_cache:
                        block_logits = logits
                    else:
                        block_logits = logits[:, :actual_block_len, :]
                    block_ids = x[:, current_block_start:current_block_end] 
                    block_metric_vals = calculate_metric(block_logits, metric='entropy') 
                    is_still_mask = (block_ids == mask_token_id)
                    masked_metric_vals = block_metric_vals[is_still_mask]
                    
                    if masked_metric_vals.numel() > 0:
                        avg_val_mask = masked_metric_vals.float().mean().item()
                    else:
                        avg_val_mask = 0.0

                    if i==0:
                        initial_block_entropy = avg_val_mask

                    threshold = get_dynamic_threshold_by_entropy(
                        current_entropy=avg_val_mask,
                        base_threshold=base_threshold,
                        min_threshold=min_threshold,
                        pivot_entropy=initial_block_entropy,
                        confidence_boost=confidence_boost,
                        method=dynamic_threshold_method
                    )

                mask_logits = logits[mask_index] 
                confidence, x0 = sample_tokens(mask_logits, temperature=temperature, top_p=top_p, top_k=top_k)
                
                if dual_cache:
                    x_ = torch.zeros_like(x[:, current_block_start:current_block_end], device=self.device, dtype=torch.long) + mask_token_id
                    full_confidence = torch.full_like(x[:, current_block_start:current_block_end], -torch.inf, device=self.device, dtype=logits.dtype)
                else:
                    x_ = torch.zeros_like(x[:, current_block_start:], device=self.device, dtype=torch.long) + mask_token_id
                    full_confidence = torch.full_like(x[:, current_block_start:], -torch.inf, device=self.device, dtype=logits.dtype)
                
                x_[mask_index] = x0.clone()
                full_confidence[mask_index] = confidence
                full_confidence[:, actual_block_len:] = -torch.inf

                current_transfer_tokens = (x[:, current_block_start:current_block_end] == mask_token_id).sum()
                
                selected_confidence, select_index = torch.topk(full_confidence, current_transfer_tokens)
                transfer_index = torch.zeros_like(x_, device=x.device, dtype=torch.bool)
                
                select_index = select_index.to(x.device)
                transfer_index[0, select_index[0]] = True
                if current_transfer_tokens > 0:
                    for k in range(1, current_transfer_tokens):
                        if selected_confidence[0, k] < threshold:
                            transfer_index[0, select_index[0, k]] = False
                if dual_cache:
                    x[:, current_block_start:current_block_end][transfer_index] = x_[transfer_index]
                else:
                    x[:, current_block_start:][transfer_index] = x_[transfer_index]
                i += 1

            current_block_start=current_block_end

        if return_dict_in_generate:
            return {
                "sequences": x,
                "history": histories,
                "nfe": nfe 
            }
        else:
            return x

    def _sample_no_cache(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.LongTensor],
        generation_config: DreamGenerationConfig,
        threshold: Optional[float] = 0.9,
        block_length: Optional[int] = 32
    ) -> Union[DreamModelOutput, torch.LongTensor]:
        output_history = generation_config.output_history
        return_dict_in_generate = generation_config.return_dict_in_generate
        max_length = generation_config.max_length
        mask_token_id = generation_config.mask_token_id
        steps = generation_config.steps
        temperature = generation_config.temperature
        top_p = generation_config.top_p
        top_k = generation_config.top_k
        alg = generation_config.alg
        alg_temp = generation_config.alg_temp

        histories = [] if (return_dict_in_generate and output_history) else None

        x = F.pad(input_ids, (0, max_length - input_ids.shape[1]), value=mask_token_id)
        gen_length = max_length - input_ids.shape[1]
        
        if block_length is None:
            block_length = gen_length
        
        assert gen_length % block_length == 0, f"gen_length ({gen_length}) must be divisible by block_length ({block_length})"
        num_blocks = gen_length // block_length
        
        assert steps % num_blocks == 0, f"steps ({steps}) must be divisible by num_blocks ({num_blocks})"
        steps_per_block = steps // num_blocks
        timesteps = torch.linspace(1, generation_config.eps, steps_per_block + 1, device=x.device)

        if attention_mask is not None and torch.any(attention_mask == 0.0):
            attention_mask = F.pad(attention_mask, (0, max_length - attention_mask.shape[1]), value=1.0)
            tok_idx = attention_mask.long().cumsum(-1) - 1
            tok_idx.masked_fill_(attention_mask == 0, 1)
            attention_mask = torch.logical_and(
                attention_mask.unsqueeze(1).unsqueeze(-2),
                attention_mask.unsqueeze(1).unsqueeze(-1),
            )
        else:
            tok_idx = None
            attention_mask = "full"

        nfe=0
        prompt_len = input_ids.shape[1]

        for num_block in range(num_blocks):
            
            current_block_start = input_ids.shape[1] + num_block * block_length
            current_block_end = current_block_start + block_length

            i = 0
            while True:
                mask_index = (x[:, current_block_start:current_block_end] == mask_token_id)
                                
                model_output = self(x, attention_mask, tok_idx, use_cache=False)

                logits = model_output.logits
                logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)

                nfe+=1

                current_block_logits = logits[:, current_block_start:current_block_end]
                if alg == 'confidence_threshold':
                    mask_logits = current_block_logits[mask_index]
                    confidence, x0 = sample_tokens(mask_logits, temperature=temperature, top_p=top_p, top_k=top_k)
                    
                    x_ = torch.zeros_like(x[:, current_block_start:current_block_end], device=self.device, dtype=torch.long) + mask_token_id
                    full_confidence = torch.full_like(x[:, current_block_start:current_block_end], -torch.inf, device=self.device, dtype=logits.dtype)
                    
                    x_[mask_index] = x0.clone()
                    full_confidence[mask_index] = confidence
                    
                    current_transfer_tokens = (x[:, current_block_start:current_block_end] == mask_token_id).sum()
                    
                    selected_confidence, select_index = torch.topk(full_confidence, current_transfer_tokens)
                    transfer_index = torch.zeros_like(x_, device=x.device, dtype=torch.bool)
                    
                    select_index = select_index.to(x.device)
                    transfer_index[0, select_index[0]] = True
                    for k in range(1, current_transfer_tokens):
                        if selected_confidence[0, k] < threshold:
                            transfer_index[0, select_index[0, k]] = False
                    x[:, current_block_start:current_block_end][transfer_index] = x_[transfer_index]
                else:
                    if i == steps_per_block:
                        break
                    t = timesteps[i]
                    s = timesteps[i + 1]

                    mask_logits = current_block_logits[mask_index]
                    confidence, x0 = sample_tokens(mask_logits, temperature, top_p=top_p, top_k=top_k, neg_entropy=True)
                    num_mask_token = mask_index.sum() / mask_index.shape[0]
                    number_transfer_tokens = int(num_mask_token * (1 - s / t)) if i < steps_per_block - 1 else int(num_mask_token)
                    full_confidence = torch.full_like(x[:, current_block_start:current_block_end], -torch.inf, device=self.device, dtype=logits.dtype)
                    full_confidence[mask_index] = confidence
                    
                    if number_transfer_tokens > 0:
                        if alg_temp is None or alg_temp == 0:
                            _, transfer_index = torch.topk(full_confidence, number_transfer_tokens)
                        else:
                            full_confidence = full_confidence / alg_temp
                            full_confidence = F.softmax(full_confidence, dim=-1)
                            transfer_index = torch.multinomial(full_confidence, num_samples=number_transfer_tokens)
                        x_ = torch.zeros_like(x[:, current_block_start:current_block_end], device=self.device, dtype=torch.long) + mask_token_id
                        x_[mask_index] = x0.clone()
                        row_indices = torch.arange(x.size(0), device=self.device).unsqueeze(1).expand_as(transfer_index)
                        x[:, current_block_start:current_block_end][row_indices,transfer_index] = x_[row_indices,transfer_index]
                    i += 1

                if (x[:, current_block_start:current_block_end] == mask_token_id).sum() == 0:
                    break

        if return_dict_in_generate:
            return {
                "sequences": x,
                "history": histories,
                "nfe": nfe
            }
        else:
            return x

    def _sample(
        self,
        input_ids: torch.LongTensor,
        attention_mask: Optional[torch.LongTensor],
        generation_config: DreamGenerationConfig,
        threshold: Optional[float] = 0.9,
        block_length: Optional[int] = 32,
        dual_cache: bool = False,
    ) -> Union[DreamModelOutput, torch.LongTensor]:
        
        output_history = generation_config.output_history
        return_dict_in_generate = generation_config.return_dict_in_generate
        max_length = generation_config.max_length
        mask_token_id = generation_config.mask_token_id
        steps = generation_config.steps
        temperature = generation_config.temperature
        top_p = generation_config.top_p
        top_k = generation_config.top_k
        alg = generation_config.alg
        alg_temp = generation_config.alg_temp

        histories = [] if (return_dict_in_generate and output_history) else None

        x = F.pad(input_ids, (0, max_length - input_ids.shape[1]), value=mask_token_id)
        gen_length = max_length - input_ids.shape[1]
        
        if block_length is None:
            block_length = gen_length 
        
        assert gen_length % block_length == 0, f"gen_length ({gen_length}) must be divisible by block_length ({block_length})"
        num_blocks = gen_length // block_length
        
        assert steps % num_blocks == 0, f"steps ({steps}) must be divisible by num_blocks ({num_blocks})"
        steps_per_block = steps // num_blocks
        timesteps = torch.linspace(1, generation_config.eps, steps_per_block + 1, device=x.device)

        if attention_mask is not None and torch.any(attention_mask == 0.0):
            attention_mask = F.pad(attention_mask, (0, max_length - attention_mask.shape[1]), value=1.0)
            tok_idx = attention_mask.long().cumsum(-1) - 1
            tok_idx.masked_fill_(attention_mask == 0, 1)
            attention_mask = torch.logical_and(
                attention_mask.unsqueeze(1).unsqueeze(-2),
                attention_mask.unsqueeze(1).unsqueeze(-1),
            )
        else:
            tok_idx = None
            attention_mask = "full"

        past_key_values = None

        nfe=0

        for num_block in range(num_blocks):
            
            current_block_start = input_ids.shape[1] + num_block * block_length
            current_block_end = current_block_start + block_length

            model_output = self(x, attention_mask, tok_idx, use_cache=True)
            past_key_values = model_output.past_key_values
            logits = model_output.logits
            logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)
            confidence, x0 = sample_tokens(logits, temperature=temperature, top_p=top_p, top_k=top_k)
            x[:, current_block_start] = x0[:, current_block_start]

            nfe += 1
            
            if not dual_cache:
                new_past_key_values = []
                for i in range(len(past_key_values)):
                    new_past_key_values.append(())
                    for j in range(len(past_key_values[i])):
                        new_past_key_values[i] += (past_key_values[i][j][:, :current_block_start, :],)
                past_key_values = new_past_key_values
            else:
                replace_position = torch.zeros_like(x, dtype=torch.bool)
                replace_position[:, current_block_start:current_block_end] = 1
                
            i = 1
            while True:
                if dual_cache:
                    mask_index = (x[:, current_block_start:current_block_end] == mask_token_id)
                else:
                    mask_index = (x[:, current_block_start:] == mask_token_id)
                
                if attention_mask != "full":
                    current_attention_mask = attention_mask[:, :, :, current_block_start:]
                else:
                    current_attention_mask = attention_mask
                
                if dual_cache:
                    model_output = self(x[:, current_block_start:current_block_end], current_attention_mask, 
                                        tok_idx[:, current_block_start:current_block_end] if tok_idx is not None else None, 
                                        past_key_values=past_key_values, use_cache=True, dual_cache=dual_cache, replace_position=replace_position)
                else:
                    model_output = self(x[:, current_block_start:], current_attention_mask, 
                                        tok_idx[:, current_block_start:] if tok_idx is not None else None, 
                                        past_key_values=past_key_values, use_cache=True)
                logits = model_output.logits
                logits = torch.cat([logits[:,:1], logits[:, :-1]], dim=1)
                nfe += 1
                if alg == 'confidence_threshold':
                    mask_logits = logits[mask_index]
                
                    confidence, x0 = sample_tokens(mask_logits, temperature=temperature, top_p=top_p, top_k=top_k)
                    
                    if dual_cache:
                        x_ = torch.zeros_like(x[:, current_block_start:current_block_end], device=self.device, dtype=torch.long) + mask_token_id
                        full_confidence = torch.full_like(x[:, current_block_start:current_block_end], -torch.inf, device=self.device, dtype=logits.dtype)
                    else:
                        x_ = torch.zeros_like(x[:, current_block_start:], device=self.device, dtype=torch.long) + mask_token_id
                        full_confidence = torch.full_like(x[:, current_block_start:], -torch.inf, device=self.device, dtype=logits.dtype)
                    
                    x_[mask_index] = x0.clone()
                    full_confidence[mask_index] = confidence
                    full_confidence[:, block_length:] = -torch.inf
                    
                    current_transfer_tokens = (x[:, current_block_start:current_block_end] == mask_token_id).sum()
                    
                    selected_confidence, select_index = torch.topk(full_confidence, current_transfer_tokens)
                    transfer_index = torch.zeros_like(x_, device=x.device, dtype=torch.bool)
                    
                    select_index = select_index.to(x.device)
                    transfer_index[0, select_index[0]] = True
                    for k in range(1, current_transfer_tokens):
                        if selected_confidence[0, k] < threshold:
                            transfer_index[0, select_index[0, k]] = False
                    if dual_cache:
                        x[:, current_block_start:current_block_end][transfer_index] = x_[transfer_index]
                    else:
                        x[:, current_block_start:][transfer_index] = x_[transfer_index]
                else:
                    if i == steps_per_block:
                        break
                    t = timesteps[i]
                    s = timesteps[i + 1]
                    mask_index[:, block_length:] = False
                    mask_logits = logits[mask_index]
                    confidence, x0 = sample_tokens(mask_logits, temperature, top_p=top_p, top_k=top_k, neg_entropy=True)
                    num_mask_token = mask_index.sum() / mask_index.shape[0]
                    number_transfer_tokens = int(num_mask_token * (1 - s / t)) if i < steps_per_block - 1 else int(num_mask_token)
                    if dual_cache:
                        full_confidence = torch.full_like(x[:, current_block_start:current_block_end], -torch.inf, device=self.device, dtype=logits.dtype)
                    else:
                        full_confidence = torch.full_like(x[:, current_block_start:], -torch.inf, device=self.device, dtype=logits.dtype)
                    full_confidence[mask_index] = confidence
                    full_confidence[:, block_length:] = -torch.inf
                    
                    if number_transfer_tokens > 0:
                        if alg_temp is None or alg_temp == 0:
                            _, transfer_index = torch.topk(full_confidence, number_transfer_tokens)
                        else:
                            full_confidence = full_confidence / alg_temp
                            full_confidence = F.softmax(full_confidence, dim=-1)
                            transfer_index = torch.multinomial(full_confidence, num_samples=number_transfer_tokens)
                        if dual_cache:
                            x_ = torch.zeros_like(x[:, current_block_start:current_block_end], device=self.device, dtype=torch.long) + mask_token_id
                        else:
                            x_ = torch.zeros_like(x[:, current_block_start:], device=self.device, dtype=torch.long) + mask_token_id
                        x_[mask_index] = x0.clone()
                        row_indices = torch.arange(x.size(0), device=self.device).unsqueeze(1).expand_as(transfer_index)
                        if dual_cache:
                            x[:, current_block_start:current_block_end][row_indices,transfer_index] = x_[row_indices,transfer_index]
                        else:
                            x[:, current_block_start:][row_indices,transfer_index] = x_[row_indices,transfer_index]
                    i += 1

                if (x[:, current_block_start:current_block_end] == mask_token_id).sum() == 0:
                    break
        
        if return_dict_in_generate:
            return {
                "sequences": x,
                "history": histories,
                "nfe": nfe
            }
        else:
            return x